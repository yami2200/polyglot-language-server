console.log("test")
let obj = {test : 1, ooi : " test "};
let myVariable = 'Bob';
myVariable = 'Étienne';
function setUserName() {
  let myName = prompt('Veuillez saisir votre nom.');
  localStorage.setItem('nom', myName);
  myHeading.textContent = 'Mozilla est cool, ' + myName;
}
if (!localStorage.getItem('nom')) {
  setUserName();
} else {
  let storedName = localStorage.getItem('nom');
  myHeading.textContent = 'Mozilla est cool, ' + storedName;
}

console.log("oui evidemment")
let x = 12;